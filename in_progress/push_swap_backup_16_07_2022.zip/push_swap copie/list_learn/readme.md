receive int argc c and char **argv

malloc a sting of int sizeof argc

validate is args are numbers and spaces

   
